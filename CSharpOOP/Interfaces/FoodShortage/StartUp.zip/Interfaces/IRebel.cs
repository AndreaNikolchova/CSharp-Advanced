﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodShortage.Interfaces
{
    public interface IRebel
    {
        string Name { get; }
        int Age { get; }
        string Group { get; }
    }
}
