﻿namespace Raiding.IO
{
    public interface IWriter
    {
        void WriteLine(string line);
    }
}
 